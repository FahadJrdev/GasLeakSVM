"""
STEP 5 - The main model: standardisation + RBF-SVM, tuned by grid search with 5-fold cross-validation.
Report: Sections 3.6-3.7 and 4.3.  Expected: best C = 100, gamma = 10, CV accuracy about 97.6%.
This is the slowest step (42 settings x 5 folds = 210 fits). About 2-4 minutes on a 4-core laptop (older or 2-core machines: up to 10).
Slow computer? Run  python 05_tune_rbf_svm.py --quick  : a smaller 3 x 3 grid, about 10-20 seconds,
same best answer (C = 100, gamma = 10); only the heat map has fewer cells.
Saves: outputs/models/best_rbf_svm.joblib   (used by steps 06, 08, 09)
       outputs/results/grid_search_cv_accuracy.csv
       outputs/figures/fig_grid_heatmap.png
"""
import sys
import time

import joblib
import seaborn as sns
from sklearn.base import clone
from sklearn.model_selection import GridSearchCV, StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from common import *

X_train, X_val, X_test, y_train, y_val, y_test = get_split()

# Speed-up: search WITHOUT probability estimates (they only matter for ROC curves, and they make each
# fit about 5x slower). Predictions, and therefore the chosen C and gamma, are identical either way.
# The winning setting is refitted once WITH probability=True further down.
pipe = Pipeline([("scaler", StandardScaler()),
                 ("svm", SVC(kernel="rbf", random_state=SEED))])
QUICK = "--quick" in sys.argv
if QUICK:
    param_grid = {"svm__C": [1, 10, 100], "svm__gamma": [0.1, 1, 10]}
else:
    param_grid = {"svm__C": [0.1, 1, 10, 100, 1000, 10000],
                  "svm__gamma": [0.001, 0.01, 0.1, 1, 10, 30, 100]}
n_settings = len(param_grid["svm__C"]) * len(param_grid["svm__gamma"])
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
grid = GridSearchCV(pipe, param_grid, cv=cv, scoring="accuracy", n_jobs=-1, verbose=1)

print(f"Searching {n_settings} settings with 5-fold CV ({'QUICK mode' if QUICK else 'full grid'}) ... please wait.")
t0 = time.perf_counter()
grid.fit(X_train, y_train)
print(f"Done in {time.perf_counter() - t0:.1f} s")

print("\nBest parameters :", grid.best_params_)
print(f"Best CV accuracy: {grid.best_score_ * 100:.2f}%")

# Refit the winner on the training set, this time with probability estimates (needed by step 06 and 09)
best = clone(grid.best_estimator_).set_params(svm__probability=True).fit(X_train, y_train)
print("\nTuned RBF-SVM")
for Xs, ys, name in [(X_train, y_train, "train"), (X_val, y_val, "validation"), (X_test, y_test, "test")]:
    m = evaluate(best, Xs, ys, name)
    print(f"  {name:<10} accuracy {m['accuracy'] * 100:6.2f}%   macro F1 {m['f1_macro']:.4f}")
print("Support vectors per class:", dict(zip(CLASSES, best.named_steps["svm"].n_support_.tolist())),
      "  total:", int(best.named_steps["svm"].n_support_.sum()))

joblib.dump(best, MODELS / "best_rbf_svm.joblib")
print(f"\n  saved model -> {MODELS / 'best_rbf_svm.joblib'}")

# Heat map of mean CV accuracy for each (C, gamma)
heat = pd.DataFrame(grid.cv_results_).pivot_table(index="param_svm__C", columns="param_svm__gamma",
                                                  values="mean_test_score")
heat.to_csv(RES / "grid_search_cv_accuracy.csv")
heat.index = [f"{v:g}" for v in heat.index]
heat.columns = [f"{v:g}" for v in heat.columns]
plt.figure(figsize=(7, 5))
sns.heatmap(heat, annot=True, fmt=".3f", cmap="viridis")
plt.xlabel(r"Kernel parameter $\gamma$")
plt.ylabel("Regularisation parameter C")
plt.title("5-Fold Cross-Validation Accuracy (RBF-SVM Grid Search)")
save_fig("fig_grid_heatmap.png")
