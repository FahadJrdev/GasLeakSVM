"""
STEP 1 - Load the dataset and look at it.
Report: Section 3.2 (data collection).
Saves nothing; only prints.
"""
from common import *

df = load_data()

print("First 5 rows:")
print(df.head().to_string())
print("\nShape (rows, columns):", df.shape)
print("\nSamples per class:")
print(df["Gas"].value_counts().to_string())
print("\nMissing values:", int(df.isna().sum().sum()))
print("\nClass means (ADC counts):")
print(df.groupby("Gas")[SENSORS].mean().round(1).loc[CLASSES].to_string())

X, y = get_xy(df)
print("\nFeature matrix X:", X.shape, "  labels y:", y.shape, "  label codes:", dict(enumerate(CLASSES)))
