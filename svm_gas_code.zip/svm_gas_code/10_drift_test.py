"""
STEP 10 - Robustness check: train on the EARLIER readings, test on the LATER ones.
Report: Section 4.8 / Limitations.  Expected accuracy: about 54%.
Why it matters: random splits mix neighbouring readings into train and test; a real sensor only
ever sees the future. The big drop shows temporal drift, the main limitation of the study.
Independent of the other steps.
"""
from sklearn.metrics import confusion_matrix
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from common import *

df = load_data()
X, y = get_xy(df)

train_idx, test_idx = [], []
for c in CLASSES:
    idx = df.index[df["Gas"] == c].values
    cut = int(0.7 * len(idx))                  # first 70% of each class (time order) trains
    train_idx += list(idx[:cut])
    test_idx += list(idx[cut:])

model = Pipeline([("scaler", StandardScaler()), ("svm", SVC(kernel="rbf", C=100, gamma=10))])
model.fit(X[train_idx], y[train_idx])
pred = model.predict(X[test_idx])

print(f"Train rows: {len(train_idx)}   test rows: {len(test_idx)}   (C = 100, gamma = 10, the tuned values)")
print(f"Chronological-split accuracy: {accuracy_score(y[test_idx], pred) * 100:.2f}%")
print("\nConfusion matrix (rows = true, columns = predicted):")
print(pd.DataFrame(confusion_matrix(y[test_idx], pred), index=CLASSES, columns=CLASSES).to_string())
print("\nRead it like this: Smoke readings drift towards Mixture, so the model needs recalibration over time.")
