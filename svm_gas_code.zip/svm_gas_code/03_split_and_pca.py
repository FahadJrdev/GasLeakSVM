"""
STEP 3 - Split into train / validation / test (70 / 15 / 15, stratified) and draw the PCA picture.
Report: Sections 3.3 (PCA) and 3.4 (pre-processing).
Saves: outputs/figures/fig_pca.png
"""
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

from common import *

df = load_data()
X_train, X_val, X_test, y_train, y_val, y_test = get_split(df)

print("Rows  train / validation / test :", len(y_train), "/", len(y_val), "/", len(y_test))
for name, ys in [("train", y_train), ("validation", y_val), ("test", y_test)]:
    print(f"  {name:<10}", {CLASSES[i]: int((ys == i).sum()) for i in range(4)})

# z-score scaling, learned on the TRAINING rows only
scaler = StandardScaler().fit(X_train)
print("\nTraining mean per sensor :", np.round(scaler.mean_, 1))
print("Training std  per sensor :", np.round(scaler.scale_, 1))
Z_all = scaler.transform(X_train)
print("After scaling -> mean ~", np.round(Z_all.mean(0), 3), " std ~", np.round(Z_all.std(0), 3))

# PCA of the scaled training data
pca = PCA(n_components=7).fit(Z_all)
ratio = pca.explained_variance_ratio_
print("\nVariance explained by each principal component (%):", np.round(ratio * 100, 2))
print(f"PC1 + PC2 together: {ratio[:2].sum() * 100:.2f}%   (the report rounds these to 70.2% and 87.8%)")

Z = pca.transform(Z_all)[:, :2]
plt.figure(figsize=(7, 5.5))
for i, c in enumerate(CLASSES):
    plt.scatter(Z[y_train == i, 0], Z[y_train == i, 1], s=6, alpha=0.6, label=c)
plt.xlabel(f"PC1 ({ratio[0] * 100:.1f}% variance)")
plt.ylabel(f"PC2 ({ratio[1] * 100:.1f}% variance)")
plt.title("PCA Projection of Standardised Sensor Data")
plt.legend(markerscale=3)
save_fig("fig_pca.png")
