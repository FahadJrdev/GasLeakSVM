"""
STEP 2 - Exploratory data analysis: statistics tables and four figures.
Report: Section 3.3.
Saves: outputs/results/descriptive_statistics.csv, class_wise_statistics.csv
       outputs/figures/fig_boxplots.png, fig_signals.png, fig_correlation.png, fig_class_distribution.png
"""
import seaborn as sns

from common import *

df = load_data()

# Tables
df[SENSORS].describe().round(2).to_csv(RES / "descriptive_statistics.csv")
df.groupby("Gas")[SENSORS].agg(["mean", "std"]).round(2).to_csv(RES / "class_wise_statistics.csv")
print("Descriptive statistics of the 7 sensors:")
print(df[SENSORS].describe().round(2).to_string())
print(f"  saved tables -> {RES}")

# Box plot of each sensor by class
fig, axes = plt.subplots(2, 4, figsize=(14, 6.5))
for ax, s in zip(axes.flat, SENSORS):
    sns.boxplot(data=df, x="Gas", y=s, order=CLASSES, ax=ax, palette="Set2", hue="Gas", legend=False)
    ax.set_title(s)
    ax.set_xlabel("")
    ax.set_ylabel("Sensor reading (ADC)")
    ax.tick_params(axis="x", rotation=20)
axes.flat[-1].axis("off")
save_fig("fig_boxplots.png")

# Sensor signals over time, one panel per class
fig, axes = plt.subplots(2, 2, figsize=(13, 7), sharey=True)
for ax, c in zip(axes.flat, CLASSES):
    sub = df[df["Gas"] == c]
    for s in SENSORS:
        ax.plot(sub["Serial Number"].values, sub[s].values, lw=0.8, label=s)
    ax.set_title(f"Class: {c}")
    ax.set_xlabel("Sample index (time order)")
    ax.set_ylabel("Reading (ADC)")
axes.flat[0].legend(ncol=4, fontsize=8)
save_fig("fig_signals.png")

# Correlation heat map
plt.figure(figsize=(7, 5.5))
sns.heatmap(df[SENSORS].corr(), annot=True, fmt=".2f", cmap="coolwarm", vmin=-1, vmax=1)
plt.title("Pearson Correlation Between Gas Sensors")
save_fig("fig_correlation.png")

# Class distribution
counts = df["Gas"].value_counts().reindex(CLASSES)
fig, ax = plt.subplots(figsize=(7, 4.2))
bars = ax.bar(counts.index, counts.values, color=["C0", "C1", "C2", "C3"], edgecolor="k", width=0.6)
for bar in bars:
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 25, f"{int(bar.get_height())}", ha="center")
ax.set_ylabel("Number of samples")
ax.set_ylim(0, 1850)
ax.set_title("Class Distribution of the Dataset")
ax.grid(axis="y", alpha=0.3)
save_fig("fig_class_distribution.png")
