"""
STEP 6 - Evaluate the tuned model on the test data (needs step 05 first).
Report: Section 4.3-4.5.  Expected: test accuracy about 98.23%, macro ROC-AUC about 0.9986.
Takes about 1-2 minutes (the learning curve is the slow part).
Saves: outputs/results/classification_report_test.txt
       outputs/figures/fig_confusion_improved.png, fig_roc.png, fig_learning_curve.png
"""
import seaborn as sns
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, roc_curve, auc
from sklearn.model_selection import StratifiedKFold, learning_curve
from sklearn.preprocessing import label_binarize

from common import *

best = need_model()
X_train, X_val, X_test, y_train, y_val, y_test = get_split()
y_pred = best.predict(X_test)

print("Test accuracy:", f"{accuracy_score(y_test, y_pred) * 100:.2f}%")
text = classification_report(y_test, y_pred, target_names=CLASSES, digits=4)
print("\nClassification report (test data):")
print(text)
(RES / "classification_report_test.txt").write_text(text, encoding="utf-8")
print(f"  saved report -> {RES / 'classification_report_test.txt'}")

# Leak / no-leak view: NoGas = no leak, everything else = gas present
tn, fp, fn, tp = confusion_matrix((y_test != 0).astype(int), (y_pred != 0).astype(int)).ravel()
print(f"\nLeak-detection view:  TP={tp}  TN={tn}  FP={fp}  FN={fn}")
print(f"  sensitivity {tp / (tp + fn) * 100:.2f}%   specificity {tn / (tn + fp) * 100:.2f}%   "
      f"false-alarm rate {fp / (fp + tn) * 100:.2f}%   missed-leak rate {fn / (fn + tp) * 100:.2f}%")

# Confusion matrix
cm = confusion_matrix(y_test, y_pred)
print("\nConfusion matrix (rows = true, columns = predicted):")
print(pd.DataFrame(cm, index=CLASSES, columns=CLASSES).to_string())
plt.figure(figsize=(6, 5))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, xticklabels=CLASSES, yticklabels=CLASSES)
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.title("Confusion Matrix on Test Data (RBF-SVM)")
save_fig("fig_confusion_improved.png")

# One-vs-rest ROC curves
y_score = best.predict_proba(X_test)
y_bin = label_binarize(y_test, classes=range(4))
plt.figure(figsize=(6.5, 5.5))
print("\nROC-AUC per class:")
for i, c in enumerate(CLASSES):
    fpr, tpr, _ = roc_curve(y_bin[:, i], y_score[:, i])
    a = auc(fpr, tpr)
    print(f"  {c:<8} {a:.4f}")
    plt.plot(fpr, tpr, lw=2, label=f"{c} (AUC = {a:.4f})")
print(f"  macro    {roc_auc_score(y_bin, y_score, average='macro'):.4f}")
plt.plot([0, 1], [0, 1], "k--", label="Chance level")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("One-vs-Rest ROC Curves (RBF-SVM, Test Data)")
plt.legend(loc="lower right")
save_fig("fig_roc.png")

# Learning curve (about 1 minute)
print("\nComputing the learning curve ...")
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
sizes, tr_sc, va_sc = learning_curve(best, X_train, y_train, cv=cv, n_jobs=-1,
                                     train_sizes=np.linspace(0.1, 1.0, 8), scoring="accuracy")
plt.figure(figsize=(7, 5))
plt.plot(sizes, tr_sc.mean(1), "o-", label="Training accuracy")
plt.plot(sizes, va_sc.mean(1), "o-", label="Cross-validation accuracy")
plt.fill_between(sizes, va_sc.mean(1) - va_sc.std(1), va_sc.mean(1) + va_sc.std(1), alpha=0.2)
plt.xlabel("Number of training samples")
plt.ylabel("Accuracy")
plt.title("Learning Curve of RBF-SVM")
plt.legend()
plt.grid(alpha=0.3)
save_fig("fig_learning_curve.png")
