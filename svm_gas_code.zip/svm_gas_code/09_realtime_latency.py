"""
STEP 9 - Real-time check: how long does one prediction take? (needs step 05 first)
Report: Section 4.7.  Sensors log a reading every 2 s; the SVM needs about 1 ms.
The exact milliseconds depend on YOUR computer, so they will differ from the report a little.
Saves: outputs/figures/fig_latency.png, outputs/results/sample_predictions.csv
"""
import time

from common import *

best = need_model()
df = load_data()
X_train, X_val, X_test, y_train, y_val, y_test = get_split(df)

stream = X_test[:500]
best.predict(stream[:1])                       # warm-up call, not timed
lat = []
for row in stream:                             # one reading at a time, like a live sensor
    t0 = time.perf_counter()
    best.predict(row.reshape(1, -1))
    lat.append((time.perf_counter() - t0) * 1000)
lat = np.array(lat)

t0 = time.perf_counter()
best.predict(X_test)
batch_ms = (time.perf_counter() - t0) * 1000 / len(X_test)

print("Prediction time for ONE reading (ms) over 500 readings:")
print(f"  mean {lat.mean():.2f}   median {np.median(lat):.2f}   95th percentile {np.percentile(lat, 95):.2f}   "
      f"max {lat.max():.2f}")
print(f"Batch prediction: {batch_ms:.3f} ms per sample")
print(f"Sensors send a reading every 2000 ms, so this is about {2000 / lat.mean():.0f}x faster than needed.")

plt.figure(figsize=(7, 4.5))
plt.hist(lat, bins=40, color="steelblue", edgecolor="white")
plt.axvline(lat.mean(), color="red", ls="--", label=f"Mean = {lat.mean():.3f} ms")
plt.xlabel("Prediction time per reading (ms)")
plt.ylabel("Frequency")
plt.title("Single-Reading Inference Latency of RBF-SVM")
plt.legend()
save_fig("fig_latency.png")

# A small simulated stream: 2 readings from each class, predicted one by one
rows = []
for c in CLASSES:
    sub = df[df["Gas"] == c].sort_values("Serial Number").iloc[::200].head(2)
    for _, r in sub.iterrows():
        prob = best.predict_proba(r[SENSORS].values.astype(float).reshape(1, -1))[0]
        rows.append({"sample": f"{r['Serial Number']}_{c}", "true": c, "predicted": CLASSES[int(prob.argmax())],
                     **{f"P({k})": round(float(v), 4) for k, v in zip(CLASSES, prob)}})
sim = pd.DataFrame(rows)
sim.to_csv(RES / "sample_predictions.csv", index=False)
print("\nSimulated live stream:")
print(sim.to_string(index=False))
print(f"\n  saved table -> {RES / 'sample_predictions.csv'}")
