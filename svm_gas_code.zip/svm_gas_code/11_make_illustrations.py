"""
STEP 11 - Illustrative and conceptual figures for the report (flowcharts, SVM geometry, kernels).
No training needed; independent of every other step.
Run: python 11_make_illustrations.py   -> writes PNGs into outputs/figures
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
from matplotlib.colors import ListedColormap
from sklearn.svm import SVC
from sklearn.datasets import make_blobs, make_moons

BASE = os.path.dirname(os.path.abspath(__file__))
FIG = os.path.join(BASE, "outputs", "figures")
RAW = os.path.join(BASE, "data")
os.makedirs(FIG, exist_ok=True)
plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "DejaVu Serif"],
                     "font.size": 11, "figure.dpi": 150, "mathtext.fontset": "stix"})

BLUE, ORANGE, GREEN, RED, GREY = "#1f4e79", "#c55a11", "#548235", "#c00000", "#595959"
LIGHT = {"blue": "#deebf7", "orange": "#fbe5d6", "green": "#e2f0d9", "grey": "#f2f2f2", "red": "#fde2e2"}


def box(ax, x, y, w, h, text, fc, ec=BLUE, fs=10.5, bold=False):
    ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="round,pad=0.02,rounding_size=0.08",
                                fc=fc, ec=ec, lw=1.4))
    ax.text(x, y, text, ha="center", va="center", fontsize=fs, weight="bold" if bold else "normal", wrap=True)


def arrow(ax, x1, y1, x2, y2, color=BLUE):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=16, lw=1.6, color=color))


def save(name):
    plt.savefig(os.path.join(FIG, name), bbox_inches="tight", dpi=200)
    plt.close()


# 1. Research framework flowchart -------------------------------------------------------------
fig, ax = plt.subplots(figsize=(10, 6.2)); ax.set_xlim(-0.15, 10.15); ax.set_ylim(0, 6.2); ax.axis("off")
steps = [(1.4, 5.3, "Data Acquisition\n7 MQ gas sensors\n(MultimodalGasData)", LIGHT["blue"]),
         (5.0, 5.3, "Exploratory Data Analysis\nstatistics, box plots,\ncorrelation, PCA", LIGHT["blue"]),
         (8.6, 5.3, "Pre-processing\nstratified 70/15/15 split,\nz-score standardisation", LIGHT["blue"]),
         (8.6, 3.1, "Baseline Model\nlinear SVM on\nraw readings", LIGHT["orange"]),
         (5.0, 3.1, "Model Improvement\nRBF kernel + grid search\n(C, $\\gamma$), 5-fold CV", LIGHT["orange"]),
         (1.4, 3.1, "Final RBF-SVM\nrefit on training set\nwith optimal (C*, $\\gamma$*)", LIGHT["orange"]),
         (1.4, 0.9, "Evaluation\naccuracy, precision, recall,\nF1, confusion matrix, ROC", LIGHT["green"]),
         (5.0, 0.9, "Real-Time Analysis\nper-reading latency,\nstreaming simulation", LIGHT["green"]),
         (8.6, 0.9, "Robustness Check\nchronological split,\ndrift discussion", LIGHT["green"])]
for x, y, t, c in steps:
    box(ax, x, y, 2.9, 1.45, t, c)
for (x1, y1), (x2, y2) in [((2.85, 5.3), (3.55, 5.3)), ((6.45, 5.3), (7.15, 5.3)), ((8.6, 4.57), (8.6, 3.83)),
                           ((7.15, 3.1), (6.45, 3.1)), ((3.55, 3.1), (2.85, 3.1)), ((1.4, 2.37), (1.4, 1.63)),
                           ((2.85, 0.9), (3.55, 0.9)), ((6.45, 0.9), (7.15, 0.9))]:
    arrow(ax, x1, y1, x2, y2)
save("fig_framework.png")

# 2. Taxonomy of gas leak detection methods ---------------------------------------------------
fig, ax = plt.subplots(figsize=(11, 6.6)); ax.set_xlim(0, 11); ax.set_ylim(0, 6.6); ax.axis("off")
box(ax, 5.5, 6.05, 5.0, 0.7, "Gas Leak Detection Methods", LIGHT["blue"], fs=13, bold=True)
cols = [(1.45, "Non-technical /\nBiological", ["Trained personnel", "Trained dogs", "Visual inspection",
                                               "Smell (odorant)"]),
        (4.05, "Hardware-based\n(Exterior)", ["Acoustic emission", "Fibre-optic sensing", "Infrared thermography",
                                               "Vapour sampling", "Gas sensors (MOS,\nelectrochemical, NDIR)"]),
        (6.75, "Software-based\n(Computational)", ["Mass/volume balance", "Negative pressure wave",
                                                    "Pressure point analysis", "Transient modelling",
                                                    "Statistical / DSP"]),
        (9.55, "Data-driven /\nMachine Learning", ["Threshold alarms (IoT)", "Deep learning\n(CNN, LSTM)",
                                                     "Multimodal fusion", "Support Vector Machine\n(this study)"])]
for x, head, items in cols:
    hl = head.startswith("Data")
    box(ax, x, 4.75, 2.35, 0.85, head, LIGHT["orange"] if hl else LIGHT["grey"], ec=RED if hl else BLUE, bold=True)
    arrow(ax, x, 5.7 if abs(x - 5.5) > 2 else 5.7, x, 5.2)
    for i, it in enumerate(items):
        yy = 3.75 - i * 0.78
        this = "this study" in it
        box(ax, x, yy, 2.25, 0.62, it, LIGHT["red"] if this else "white", ec=RED if this else GREY, fs=9.5,
            bold=this)
ax.plot([1.45, 9.55], [5.55, 5.55], color=BLUE, lw=1.6); ax.plot([5.5, 5.5], [5.7, 5.55], color=BLUE, lw=1.6)
ax.text(5.5, 0.05, "Adapted from Murvay & Silea (2012) and Adegboye et al. (2019), with a data-driven branch added.",
        ha="center", fontsize=9, style="italic", color=GREY)
save("fig_taxonomy.png")

# 3. Hard- and soft-margin SVM geometry -------------------------------------------------------
X, y = make_blobs(n_samples=40, centers=[[-1.6, -1.2], [1.6, 1.3]], cluster_std=0.65, random_state=3)
fig, axes = plt.subplots(1, 2, figsize=(12, 5.2))
for ax, (Xd, yd, C, title) in zip(axes, [(X, y, 1e6, "(a) Hard-margin SVM (separable data)"),
                                          (np.vstack([X, [[0.6, 0.2], [-0.5, 0.4]]]), np.r_[y, 0, 1], 1.0,
                                           "(b) Soft-margin SVM (overlapping data)")]):
    clf = SVC(kernel="linear", C=C).fit(Xd, yd)
    w, b = clf.coef_[0], clf.intercept_[0]
    xs = np.linspace(-4, 4, 50)
    for off, ls, lab in [(0, "-", r"$\mathbf{w}^\top\mathbf{x}+b=0$"), (1, "--", r"$\mathbf{w}^\top\mathbf{x}+b=+1$"),
                         (-1, "--", r"$\mathbf{w}^\top\mathbf{x}+b=-1$")]:
        ax.plot(xs, (off - b - w[0] * xs) / w[1], ls, color="k" if off == 0 else GREY, lw=1.6, label=lab)
    ax.scatter(Xd[yd == 0, 0], Xd[yd == 0, 1], c=BLUE, s=36, label="Class $y=-1$")
    ax.scatter(Xd[yd == 1, 0], Xd[yd == 1, 1], c=ORANGE, marker="s", s=36, label="Class $y=+1$")
    sv = clf.support_vectors_
    ax.scatter(sv[:, 0], sv[:, 1], s=160, facecolors="none", edgecolors=RED, lw=1.6, label="Support vectors")
    if C > 1e3:
        p0 = np.array([0.0, -b / w[1]]); n = w / np.linalg.norm(w); m = 1 / np.linalg.norm(w)
        a1, a2 = p0 - n * m, p0 + n * m
        ax.annotate("", xy=a2, xytext=a1, arrowprops=dict(arrowstyle="<->", color=GREEN, lw=1.8))
        ax.annotate(r"margin $=\dfrac{2}{\|\mathbf{w}\|}$", xy=(a1 + p0) / 2, xytext=(-3.85, 0.9), color=GREEN,
                    fontsize=12, arrowprops=dict(arrowstyle="->", color=GREEN, lw=1.0))
        ax.annotate("", xy=p0 + n * 1.3, xytext=p0, arrowprops=dict(arrowstyle="-|>", color="k", lw=1.4))
        ax.text(*(p0 + n * 1.35 + np.array([0.05, 0.05])), r"$\mathbf{w}$", fontsize=13)
    else:
        f = clf.decision_function(Xd); viol = (np.where(yd == 1, 1, -1) * f) < 1
        for p in Xd[viol]:
            ax.annotate(r"$\xi_i$", xy=p, xytext=p + np.array([0.25, 0.25]), fontsize=11, color=RED)
    ax.set_xlim(-4, 4); ax.set_ylim(-3.5, 3.5); ax.set_xlabel("$x_1$"); ax.set_ylabel("$x_2$")
    ax.set_title(title); ax.legend(fontsize=8.5, loc="lower right"); ax.grid(alpha=0.25)
plt.tight_layout(); save("fig_svm_margin.png")

# 4. Kernel trick illustration: 1-D -> 2-D mapping ---------------------------------------------
rng = np.random.default_rng(0)
x_in = np.r_[rng.uniform(-1, 1, 14)]; x_out = np.r_[rng.uniform(-3, -1.6, 8), rng.uniform(1.6, 3, 8)]
fig, axes = plt.subplots(1, 2, figsize=(12, 4.4))
axes[0].scatter(x_in, np.zeros_like(x_in), c=BLUE, s=45, label="Class A")
axes[0].scatter(x_out, np.zeros_like(x_out), c=ORANGE, marker="s", s=45, label="Class B")
axes[0].set_yticks([]); axes[0].set_xlabel("$x$"); axes[0].axhline(0, color=GREY, lw=0.8)
axes[0].set_title("(a) Input space $\\mathbb{R}$: no single threshold separates the classes"); axes[0].legend()
axes[1].scatter(x_in, x_in ** 2, c=BLUE, s=45, label="Class A")
axes[1].scatter(x_out, x_out ** 2, c=ORANGE, marker="s", s=45, label="Class B")
axes[1].axhline(1.9, color="k", ls="-", lw=1.6, label="Linear separator in feature space")
xx = np.linspace(-3.2, 3.2, 200); axes[1].plot(xx, xx ** 2, color=GREY, lw=0.8, ls=":")
axes[1].set_xlabel("$\\phi_1(x)=x$"); axes[1].set_ylabel("$\\phi_2(x)=x^2$")
axes[1].set_title("(b) Feature space $\\phi(x)=(x,\\,x^2)$: linearly separable"); axes[1].legend(fontsize=9)
for a in axes: a.grid(alpha=0.25)
plt.tight_layout(); save("fig_kernel_trick.png")

# 5. RBF kernel: kernel profile and effect of gamma on the boundary ---------------------------
Xm, ym = make_moons(n_samples=220, noise=0.22, random_state=1)
fig, axes = plt.subplots(1, 4, figsize=(16, 3.9))
r = np.linspace(0, 3, 300)
for g, c in [(0.1, BLUE), (1, GREEN), (10, ORANGE)]:
    axes[0].plot(r, np.exp(-g * r ** 2), color=c, lw=2, label=f"$\\gamma={g}$")
axes[0].set_xlabel(r"$\|\mathbf{x}-\mathbf{z}\|$"); axes[0].set_ylabel(r"$K(\mathbf{x},\mathbf{z})$")
axes[0].set_title("(a) RBF kernel profile"); axes[0].legend(); axes[0].grid(alpha=0.25)
gx, gy = np.meshgrid(np.linspace(-1.6, 2.6, 300), np.linspace(-1.2, 1.7, 300))
for ax, g, t in zip(axes[1:], [0.1, 2, 100], ["(b) $\\gamma=0.1$ (under-fitting)", "(c) $\\gamma=2$ (balanced)",
                                              "(d) $\\gamma=100$ (over-fitting)"]):
    clf = SVC(kernel="rbf", C=10, gamma=g).fit(Xm, ym)
    zz = clf.decision_function(np.c_[gx.ravel(), gy.ravel()]).reshape(gx.shape)
    ax.contourf(gx, gy, zz > 0, alpha=0.18, cmap=ListedColormap([BLUE, ORANGE]))
    ax.contour(gx, gy, zz, levels=[0], colors="k", linewidths=1.5)
    ax.scatter(Xm[ym == 0, 0], Xm[ym == 0, 1], c=BLUE, s=12); ax.scatter(Xm[ym == 1, 0], Xm[ym == 1, 1], c=ORANGE, s=12)
    ax.set_title(t + f"\nsupport vectors = {clf.n_support_.sum()}"); ax.set_xticks([]); ax.set_yticks([])
plt.tight_layout(); save("fig_rbf_gamma.png")

# 6. One-vs-one decomposition and voting ------------------------------------------------------
fig, ax = plt.subplots(figsize=(11, 5.8)); ax.set_xlim(0, 11); ax.set_ylim(-0.5, 5.4); ax.axis("off")
box(ax, 1.1, 2.7, 1.7, 1.2, "New sensor\nreading\n$\\mathbf{x}\\in\\mathbb{R}^7$", LIGHT["blue"], bold=True)
pairs = ["NoGas vs Perfume", "NoGas vs Smoke", "NoGas vs Mixture", "Perfume vs Smoke", "Perfume vs Mixture",
         "Smoke vs Mixture"]
for i, p in enumerate(pairs):
    yy = 4.85 - i * 0.86
    box(ax, 4.6, yy, 2.9, 0.62, f"$f_{{{i + 1}}}$ : {p}", "white", fs=10)
    arrow(ax, 1.95, 2.7, 3.15, yy); arrow(ax, 6.05, yy, 7.35, 2.7)
box(ax, 8.15, 2.7, 1.55, 1.3, "Majority\nvoting\n$\\arg\\max_p v_p$", LIGHT["orange"], bold=True)
arrow(ax, 8.93, 2.7, 9.5, 2.7)
box(ax, 10.25, 2.7, 1.35, 1.0, "Predicted\nclass", LIGHT["green"], bold=True)
ax.text(4.6, -0.35, "$k(k-1)/2 = 4\\times3/2 = 6$ binary SVMs", ha="center", fontsize=11)
save("fig_ovo.png")

# 7. Stratified 5-fold cross-validation ------------------------------------------------------
fig, ax = plt.subplots(figsize=(10, 3.6)); ax.set_xlim(0, 10); ax.set_ylim(0, 6); ax.axis("off")
for k in range(5):
    yy = 4.9 - k * 1.0
    ax.text(0.6, yy, f"Iteration {k + 1}", va="center", ha="center", fontsize=10.5)
    for j in range(5):
        val = j == k
        ax.add_patch(FancyBboxPatch((1.4 + j * 1.45, yy - 0.33), 1.35, 0.66, boxstyle="round,pad=0.01",
                                    fc=ORANGE if val else "#9dc3e6", ec="white"))
        ax.text(1.4 + j * 1.45 + 0.675, yy, "Validation" if val else "Training", ha="center", va="center",
                fontsize=9.5, color="white" if val else "k")
    ax.text(9.15, yy, f"$A_{k + 1}$", va="center", fontsize=12)
ax.text(9.15, 5.65, "score", ha="center", fontsize=10)
ax.text(5.0, -0.25, r"$\mathrm{CV}(C,\gamma)=\frac{1}{5}\sum_{m=1}^{5}A_m$", ha="center", fontsize=13)
save("fig_kfold.png")

# 8. Real-time IoT deployment pipeline --------------------------------------------------------
fig, ax = plt.subplots(figsize=(12, 3.4)); ax.set_xlim(0, 12); ax.set_ylim(0, 3.4); ax.axis("off")
chain = [("MQ sensor array\n(7 MOS sensors)", LIGHT["grey"]), ("10-bit ADC\nmicrocontroller", LIGHT["grey"]),
         ("z-score\nstandardisation\n$(x-\\mu)/\\sigma$", LIGHT["blue"]), ("Trained RBF-SVM\n(OvO, 6 classifiers)",
                                                                          LIGHT["orange"]),
         ("Decision:\nNoGas / Perfume /\nSmoke / Mixture", LIGHT["green"]), ("Alarm / ventilation /\ncloud dashboard",
                                                                          LIGHT["red"])]
for i, (t, c) in enumerate(chain):
    x = 1.0 + i * 2.0
    box(ax, x, 1.9, 1.75, 1.35, t, c, fs=9.8)
    if i < len(chain) - 1:
        arrow(ax, x + 0.88, 1.9, x + 1.12, 1.9)
ax.text(6.0, 0.35, "every 2 s a new reading arrives; SVM inference takes about 1 ms", ha="center", fontsize=10.5,
        style="italic", color=GREY)
save("fig_realtime_pipeline.png")

# 9. SVM training / prediction algorithm flowchart -------------------------------------------
fig, ax = plt.subplots(figsize=(10, 4.6)); ax.set_xlim(0, 10); ax.set_ylim(0, 4.6); ax.axis("off")
top = [("Training data\n$\\{(\\mathbf{x}_i, y_i)\\}$", LIGHT["blue"]), ("Standardise\nfeatures", LIGHT["blue"]),
       ("Build kernel\nmatrix $K_{ij}$", LIGHT["blue"]), ("Solve dual QP\n(SMO) for $\\alpha_i$", LIGHT["orange"])]
bot = [("Predict class\n(OvO voting)", LIGHT["green"]), ("Decision function\n$f(\\mathbf{x})$",
                                                         LIGHT["green"]), ("Compute bias $b$\nfrom KKT", LIGHT["orange"]),
       ("Identify support\nvectors $\\alpha_i>0$", LIGHT["orange"])]
for i, (t, c) in enumerate(top):
    box(ax, 1.25 + i * 2.5, 3.5, 2.0, 1.05, t, c)
    if i < 3: arrow(ax, 2.27 + i * 2.5, 3.5, 2.73 + i * 2.5, 3.5)
for i, (t, c) in enumerate(bot):
    box(ax, 1.25 + i * 2.5, 1.1, 2.0, 1.05, t, c)
    if i < 3: arrow(ax, 2.73 + i * 2.5, 1.1, 2.27 + i * 2.5, 1.1)
arrow(ax, 8.75, 2.95, 8.75, 1.65)
save("fig_svm_algorithm.png")

# 10. Thermal image samples (one per class) ---------------------------------------------------
fig, axes = plt.subplots(1, 4, figsize=(13, 4.6))
for ax, c in zip(axes, ["NoGas", "Perfume", "Smoke", "Mixture"]):
    p = os.path.join(RAW, f"0_{c}.png")
    if os.path.exists(p):
        ax.imshow(plt.imread(p))
    ax.set_title(c, fontsize=13); ax.axis("off")
plt.tight_layout(); save("fig_thermal_samples.png")

# 11. Class distribution ---------------------------------------------------------------------
df = pd.read_csv(os.path.join(RAW, "Gas_Sensors_Measurements.csv"))
counts = df["Gas"].value_counts().reindex(["NoGas", "Perfume", "Smoke", "Mixture"])
fig, ax = plt.subplots(figsize=(7, 4.2))
bars = ax.bar(counts.index, counts.values, color=["C0", "C1", "C2", "C3"], edgecolor="k", width=0.6)
for bar in bars:
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 25, f"{int(bar.get_height())}", ha="center")
ax.set_ylabel("Number of samples"); ax.set_ylim(0, 1850); ax.set_title("Class Distribution of the Dataset")
ax.grid(axis="y", alpha=0.3)
save("fig_class_distribution.png")
print("Illustrations written to", FIG)
