"""
Run every step in order, one after another, and stop at the first error.

    python run_all.py            (full grids: about 10-15 minutes on a 4-core laptop)
    python run_all.py --quick    (smaller grids: about 5 minutes; same final numbers)

It uses the same Python that runs this file, so activate your virtual environment first.
"""
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
STEPS = ["00_check_setup.py", "01_load_data.py", "02_explore_data.py", "03_split_and_pca.py",
         "04_baseline_linear_svm.py", "05_tune_rbf_svm.py", "06_evaluate_model.py",
         "07_kernel_comparison.py", "08_decision_regions.py", "09_realtime_latency.py",
         "10_drift_test.py", "11_make_illustrations.py"]

start = time.time()
for step in STEPS:
    print("\n" + "=" * 78 + f"\n  {step}\n" + "=" * 78, flush=True)
    t0 = time.time()
    if subprocess.run([sys.executable, str(HERE / step)] + sys.argv[1:], cwd=str(HERE)).returncode != 0:
        print(f"\nSTOPPED: {step} failed. Read the red error above, fix it, then run again.")
        sys.exit(1)
    print(f"\n[{step} finished in {time.time() - t0:.1f} s]")

print(f"\nALL {len(STEPS)} STEPS FINISHED in {time.time() - start:.0f} s.")
print(f"Open the folders  {HERE / 'outputs' / 'figures'}  and  {HERE / 'outputs' / 'results'}")
