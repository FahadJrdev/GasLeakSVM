"""
STEP 0 - Check that your computer is ready.
Prints the Python version, which libraries are installed, and whether the data file is in place.
Nothing is trained and nothing is saved.
"""
import importlib
import sys
from pathlib import Path

print("Python  :", sys.version.split()[0], "at", sys.executable)
if sys.version_info < (3, 9):
    print("  PROBLEM: Python 3.9 or newer is needed. Install a newer Python from python.org.")

missing = []
for name in ["numpy", "pandas", "matplotlib", "seaborn", "sklearn", "joblib"]:
    try:
        module = importlib.import_module(name)
        print(f"{name:<11}: {module.__version__}")
    except ImportError:
        print(f"{name:<11}: NOT INSTALLED")
        missing.append(name)

csv = Path(__file__).resolve().parent / "data" / "Gas_Sensors_Measurements.csv"
print("Data    :", "found" if csv.exists() else "MISSING", "->", csv)

if missing or not csv.exists():
    print("\nNOT READY.")
    if missing:
        print("Install the libraries with:  python -m pip install -r requirements.txt")
        print("(make sure the VS Code terminal shows (.venv) before you run it)")
    sys.exit(1)
print("\nALL GOOD. You can run 01_load_data.py next.")
