"""
Shared helpers for every step script (01_..., 02_..., ...).
You do not run this file. The step scripts import it.

Everything is found relative to THIS file, so the folder can live anywhere
(Desktop, Documents, a USB stick) on Windows, macOS or Linux.
"""
import warnings
from pathlib import Path

import matplotlib
matplotlib.use("Agg")                       # save PNG files; never opens a blocking window
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from sklearn.model_selection import train_test_split

warnings.filterwarnings("ignore")

HERE = Path(__file__).resolve().parent
DATA_DIR = HERE / "data"
DATA_CSV = DATA_DIR / "Gas_Sensors_Measurements.csv"
OUT = HERE / "outputs"
FIG = OUT / "figures"
RES = OUT / "results"
MODELS = OUT / "models"
for _d in (FIG, RES, MODELS):
    _d.mkdir(parents=True, exist_ok=True)

SEED = 42
SENSORS = ["MQ2", "MQ3", "MQ5", "MQ6", "MQ7", "MQ8", "MQ135"]
CLASSES = ["NoGas", "Perfume", "Smoke", "Mixture"]

# Times New Roman if the computer has it, otherwise a serif font that ships with matplotlib.
plt.rcParams.update({"font.family": "serif",
                     "font.serif": ["Times New Roman", "DejaVu Serif"],
                     "font.size": 11, "figure.dpi": 150, "mathtext.fontset": "stix"})


def load_data():
    """Read the CSV. Stops with a clear message if the file is missing."""
    if not DATA_CSV.exists():
        raise SystemExit(f"Cannot find {DATA_CSV}\n"
                         "Keep the 'data' folder next to the scripts (do not move the .py files out).")
    return pd.read_csv(DATA_CSV)


def get_xy(df):
    """Feature matrix X (6400 x 7) and integer labels y (0..3)."""
    X = df[SENSORS].values.astype(float)
    y = df["Gas"].map({c: i for i, c in enumerate(CLASSES)}).values
    return X, y


def get_split(df=None):
    """Stratified 70 / 15 / 15 split. Same seed every time, so every script sees identical data."""
    if df is None:
        df = load_data()
    X, y = get_xy(df)
    X_train, X_tmp, y_train, y_tmp = train_test_split(X, y, test_size=0.30, stratify=y, random_state=SEED)
    X_val, X_test, y_val, y_test = train_test_split(X_tmp, y_tmp, test_size=0.50, stratify=y_tmp,
                                                    random_state=SEED)
    return X_train, X_val, X_test, y_train, y_val, y_test


def evaluate(model, Xs, ys, name):
    """Accuracy and macro precision / recall / F1 of a fitted model on one data split."""
    yp = model.predict(Xs)
    p, r, f, _ = precision_recall_fscore_support(ys, yp, average="macro", zero_division=0)
    return {"split": name, "accuracy": accuracy_score(ys, yp), "precision_macro": p,
            "recall_macro": r, "f1_macro": f}


def save_fig(name):
    """Tight-layout, save into outputs/figures, close, and say where it went."""
    plt.tight_layout()
    path = FIG / name
    plt.savefig(path)
    plt.close()
    print(f"  saved figure -> {path}")


def need_model():
    """Load the tuned model made by step 05, or stop with a helpful message."""
    import joblib
    path = MODELS / "best_rbf_svm.joblib"
    if not path.exists():
        raise SystemExit("The tuned model does not exist yet.\nRun 05_tune_rbf_svm.py first, then this script.")
    return joblib.load(path)
