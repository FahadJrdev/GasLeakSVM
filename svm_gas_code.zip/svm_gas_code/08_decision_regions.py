"""
STEP 8 - Draw the SVM decision regions in 2-D (PCA) space (needs step 05 first, for the best C).
Report: Section 4.6.  This is an illustration: the real model uses all 7 sensors.
Takes about 30-90 seconds (it classifies 160,000 grid points).
Saves: outputs/figures/fig_decision_regions.png
"""
from matplotlib.colors import ListedColormap
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from common import *

best = need_model()
best_C = best.named_steps["svm"].C
X_train, X_val, X_test, y_train, y_val, y_test = get_split()

vis = Pipeline([("scaler", StandardScaler()), ("pca", PCA(n_components=2)),
                ("svm", SVC(kernel="rbf", C=best_C, gamma="scale"))]).fit(X_train, y_train)
Ztr = vis[:-1].transform(X_train)
print(f"Drawing regions with C = {best_C:g}; accuracy of this 2-D model on test data: "
      f"{accuracy_score(y_test, vis.predict(X_test)) * 100:.2f}%  (lower than 98.23%: only 2 dimensions)")

xx, yy = np.meshgrid(np.linspace(Ztr[:, 0].min() - 1, Ztr[:, 0].max() + 1, 400),
                     np.linspace(Ztr[:, 1].min() - 1, Ztr[:, 1].max() + 1, 400))
zz = vis.named_steps["svm"].predict(np.c_[xx.ravel(), yy.ravel()]).reshape(xx.shape)
plt.figure(figsize=(7.5, 6))
plt.contourf(xx, yy, zz, alpha=0.20, cmap=ListedColormap(["C0", "C1", "C2", "C3"]),
             levels=[-0.5, 0.5, 1.5, 2.5, 3.5])
for i, c in enumerate(CLASSES):
    plt.scatter(Ztr[y_train == i, 0], Ztr[y_train == i, 1], s=5, label=c)
plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.title("RBF-SVM Decision Regions in 2-D PCA Space")
plt.legend(markerscale=3)
save_fig("fig_decision_regions.png")
