"""
STEP 7 - Compare SVM kernels (linear, polynomial, RBF), each tuned by 5-fold CV.
Report: Section 4.4 (kernel ablation).  Expected test accuracy: linear ~84.8%, poly ~95.5%, RBF ~98.2%.
Independent of step 05, but it repeats a grid search: about 2-5 minutes.
Slow computer? Add --quick for a smaller RBF grid (about 15 seconds).
Saves: outputs/results/kernel_comparison.csv
"""
import sys

from sklearn.model_selection import GridSearchCV, StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

from common import *

X_train, X_val, X_test, y_train, y_val, y_test = get_split()
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)

grids = {"linear": {"svm__C": [0.1, 1, 10, 100]},
         "poly": {"svm__C": [0.1, 1, 10, 100], "svm__degree": [2, 3]},
         "rbf": ({"svm__C": [1, 10, 100], "svm__gamma": [0.1, 1, 10]} if "--quick" in sys.argv else
                 {"svm__C": [0.1, 1, 10, 100, 1000, 10000], "svm__gamma": [0.001, 0.01, 0.1, 1, 10, 30, 100]})}

rows = []
for kernel, grid in grids.items():
    print(f"Tuning the {kernel} kernel ...")
    pipe = Pipeline([("scaler", StandardScaler()), ("svm", SVC(kernel=kernel, random_state=SEED))])
    gs = GridSearchCV(pipe, grid, cv=cv, scoring="accuracy", n_jobs=-1).fit(X_train, y_train)
    rows.append({"kernel": kernel, "best_params": str(gs.best_params_), "cv_accuracy": gs.best_score_,
                 "test_accuracy": accuracy_score(y_test, gs.predict(X_test))})

table = pd.DataFrame(rows)
table.to_csv(RES / "kernel_comparison.csv", index=False)
print("\nKernel comparison:")
print(table.assign(cv_accuracy=(table.cv_accuracy * 100).round(2),
                   test_accuracy=(table.test_accuracy * 100).round(2)).to_string(index=False))
print(f"\n  saved table -> {RES / 'kernel_comparison.csv'}")
