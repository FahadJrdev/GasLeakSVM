# Gas Leak Detection with SVM — run it on your own computer

This folder holds the complete experiment from the project report, split into small numbered
scripts so you can run it **one step at a time** and see each result. It works on Windows,
macOS and Linux. Nothing is installed except Python and a few libraries, inside this folder.

The full step-by-step guide, with screenshots of what to expect, is on the project site:
https://fahadjrdev.github.io/GasLeakSVM/vscode.html

## What is in the folder

| File | What it does | Report section |
|---|---|---|
| `00_check_setup.py` | Checks Python, libraries and the data file | — |
| `01_load_data.py` | Loads the CSV, prints shape and class counts | 3.2 |
| `02_explore_data.py` | Statistics tables, box plots, signals, correlation, class bars | 3.3 |
| `03_split_and_pca.py` | 70/15/15 split, z-score scaling, PCA picture | 3.3, 3.4 |
| `04_baseline_linear_svm.py` | Linear SVM on raw data (about 80.3%) | 4.2 |
| `05_tune_rbf_svm.py` | Grid search, tuned RBF-SVM, saves the model (about 98.23%) | 4.3 |
| `06_evaluate_model.py` | Report, confusion matrix, ROC curves, learning curve | 4.3–4.5 |
| `07_kernel_comparison.py` | Linear vs polynomial vs RBF | 4.4 |
| `08_decision_regions.py` | Decision regions in 2-D PCA space | 4.6 |
| `09_realtime_latency.py` | Prediction time per reading, simulated live stream | 4.7 |
| `10_drift_test.py` | Train on early readings, test on late ones (about 54%) | 4.8 |
| `11_make_illustrations.py` | The conceptual diagrams (margin, kernel trick, flowcharts) | Ch. 3 |
| `run_all.py` | Runs steps 00–11 in order | — |
| `all_in_one_svm_gas_experiment.py` | The same experiment as one single file | — |
| `common.py` | Shared helper code (not run directly) | — |
| `data/` | The sensor CSV and four thermal images | — |
| `requirements.txt` | The libraries needed | — |
| `outputs/` | Created when you run: `figures/`, `results/`, `models/` | — |

Keep the files together. Each script finds the data relative to its own location, so the folder
can sit anywhere.

## Quick start

1. Install **Python 3.9 or newer** from https://www.python.org/downloads/
   (Windows: tick **"Add python.exe to PATH"** on the first installer screen).
2. Install **Visual Studio Code** and its **Python** extension (publisher: Microsoft).
3. In VS Code: **File > Open Folder...** and choose this folder.
4. Open a terminal: **Terminal > New Terminal**, then:

   Windows (PowerShell):
   ```
   py -m venv .venv
   .venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   ```
   macOS / Linux:
   ```
   python3 -m venv .venv
   source .venv/bin/activate
   python -m pip install -r requirements.txt
   ```
   The prompt now starts with `(.venv)`. Always check for that before running anything.
5. Run the steps in order:
   ```
   python 00_check_setup.py
   python 01_load_data.py
   python 02_explore_data.py
   ...
   ```
   or everything at once: `python run_all.py` (add `--quick` on a slow computer).

Figures appear in `outputs/figures/`; click a PNG in VS Code's Explorer to view it.

## If something goes wrong

| You see | Fix |
|---|---|
| `python` / `py` is not recognised | Python is not installed or not on PATH. Reinstall and tick "Add to PATH", then reopen VS Code. |
| `running scripts is disabled on this system` (PowerShell, activating `.venv`) | Run once: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, then activate again. Or use Command Prompt: `.venv\Scripts\activate.bat`. |
| `ModuleNotFoundError: No module named 'sklearn'` (or pandas, seaborn...) | The virtual environment is not active or packages are not installed. Check for `(.venv)`, then `python -m pip install -r requirements.txt`. |
| `The tuned model does not exist yet` | Run `05_tune_rbf_svm.py` before steps 06, 08, 09. |
| Step 05 takes very long | Normal on older laptops. Use `python 05_tune_rbf_svm.py --quick`. |
| VS Code runs the wrong Python | Press `Ctrl+Shift+P` (Mac: `Cmd+Shift+P`) > **Python: Select Interpreter** > choose the one in `.venv`. |

## Data and credit

The data is MultimodalGasData (Narkhede et al., 2022), CC BY 4.0,
https://data.mendeley.com/datasets/zkwgkjkjn9
