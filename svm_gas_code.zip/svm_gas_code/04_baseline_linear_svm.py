"""
STEP 4 - Baseline: a plain linear SVM on the raw (unscaled) readings.
Report: Section 4.2 (baseline).  Expected test accuracy: about 80.3%.
Saves: outputs/figures/fig_confusion_baseline.png
"""
import time

import seaborn as sns
from sklearn.metrics import confusion_matrix
from sklearn.svm import SVC

from common import *

X_train, X_val, X_test, y_train, y_val, y_test = get_split()

baseline = SVC(kernel="linear", C=1.0, random_state=SEED, max_iter=200000)
t0 = time.perf_counter()
baseline.fit(X_train, y_train)
print(f"Trained in {time.perf_counter() - t0:.1f} s   (support vectors: {baseline.n_support_.sum()})")

print("\nBaseline linear SVM")
for Xs, ys, name in [(X_train, y_train, "train"), (X_val, y_val, "validation"), (X_test, y_test, "test")]:
    m = evaluate(baseline, Xs, ys, name)
    print(f"  {name:<10} accuracy {m['accuracy'] * 100:6.2f}%   macro F1 {m['f1_macro']:.4f}")

cm = confusion_matrix(y_test, baseline.predict(X_test))
print("\nConfusion matrix on test data (rows = true, columns = predicted):")
print(pd.DataFrame(cm, index=CLASSES, columns=CLASSES).to_string())

plt.figure(figsize=(6, 5))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, xticklabels=CLASSES, yticklabels=CLASSES)
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.title("Confusion Matrix on Test Data (Linear SVM)")
save_fig("fig_confusion_baseline.png")
